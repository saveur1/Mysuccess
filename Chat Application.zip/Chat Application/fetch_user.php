<?php

include "database_connection.php";

session_start();

$sql="SELECT *
      FROM login
      WHERE user_id != ".($_SESSION['user_id'] ?? 0)."";
$stmt=$connection->prepare($sql);
$stmt->execute();
$result=$stmt->fetchAll();
$output ="
   <table class='table table-bordered table-striped'>
   <tr>
   <th>User</th>
   <th>status</th>
   <th>chat</th>
   </tr>
  ";
  foreach($result as $row)
  {
     $status='';
     $timestamp=strtotime(date("Y-m-d h:i:s")." -13 second Africa/Kigali");
     $tenSecondsPast=date("Y-m-d H:i:s",$timestamp);
     $last_activity=getUserLastActivity($connection,$row['user_id']);
     if(strtotime($last_activity) > strtotime($tenSecondsPast))
     {
        $status="<span class='label label-success'>online</span>";
     } else {
        $status="<span class='label label-danger'>offline</span>";
     }
     $output.="
     <tr>
     <td>".$row['username']." ".set_notification($connection,$_SESSION['user_id'],$row['user_id'])." ".get_user_typing($row['user_id'],$connection)."</td>
     <td>".$status."</td>
     <td><button type='button' class='btn btn-xs btn-warning start_chat' data-touserid='".$row['user_id']."' data-tousername='".$row['username']."'>start chat</button></td>
     </tr>
     ";
  }
  $output.="</table>";
  echo $output;
?>