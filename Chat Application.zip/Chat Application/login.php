<?php
include "database_connection.php";
session_start();
if(isset($_SESSION['user_id']))
{
   header("location:index.php");
}
$message='';
if(isset($_POST['login']))
{
   /*$sql="INSERT INTO
         login(username,password)
         VALUES(:username,:password)";
   $stmt=$connection->prepare($sql);
   if($stmt->execute(array(":username" => $_POST['username'],":password" => password_hash($_POST['password'],PASSWORD_DEFAULT))))
   {
      $message="<label class='text-success'>Data inserted</label>";
   }*/
   $sql="SELECT * 
         FROM login
         WHERE username=:username";
   $statement=$connection->prepare($sql);
   $statement->execute(array(
      ":username"  => htmlspecialchars(stripslashes($_POST['username']))
   ));
   $returned_rows=$statement->rowCount();
   if($returned_rows>0)
   {
      $result=$statement->fetchAll();
      foreach($result as $row)
      {
         if(password_verify($_POST['password'],$row['password']))
         {
            $_SESSION['user_id']=$row['user_id'];
            $_SESSION['username']=$row['username'];
            $sub_sql="INSERT INTO
                      login_details(user_id)
                      VALUES(:user_id)";
            $sub_stmt=$connection->prepare($sub_sql);
            $sub_stmt->execute(array(
                 ":user_id"  => $row['user_id']
            ));
            $_SESSION['login_details_id']=$connection->lastInsertId();
            header("location:index.php");
            
         }else {
            $message="<label>Wrong Password</label>";
         }
      }
   }else {
      $message="<label>Wrong Username<label>";
   }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <title>Chat Application</title>
   <meta charset="UTF-8" />
   <meta name="description" content="Chat application" />
   <meta name="viewport" content="width=device-width,initial-scale=1.0" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <link rel='stylesheet' href='css/jquery-ui.css'>
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <script src="js/jquery-1.12.4.js"></script>
   <script src="js/jquery-ui.js"></script>
</head>
<body>
<div class="container">
   <br>
   <h3 class="text-center">Chat application in jQuery</h3>
   <br>
   <div class="panel panel-default">
      <div class="panel-heading">Chat App Login</div>
      <div class="panel-body">
         <form method="POST">
            <p class="text-danger"><?php echo $message; ?></p>
            <div class="form-group">
               <label>Username</label>
               <input type="text" name="username" value="<?php echo $_POST['username'] ?? ''; ?>" class="form-control" required>
            </div>
            <div class="form-group">
               <label>Password</label>
               <input type="password" name="password" class="form-control" required>
            </div>
            <div class="form-group">
               <input type="submit" name="login" value="Login" class="btn btn-sm btn-info">
            </div>
            <div class="text-center">
               <em>Don't Have an account <a href="registration.php">Register</a></em>
            </div>
         </form>
      </div>
   </div>
</div>
</body>
</html>