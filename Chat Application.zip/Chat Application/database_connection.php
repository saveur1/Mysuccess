<?php
$connection=new PDO("mysql:host=localhost;dbname=chat_application","root","");
function getUserLastActivity($con,$user_id)
{
   $query="SELECT *
           FROM login_details
           WHERE user_id=:user_id
           ORDER BY last_activity DESC
           LIMIT 1";
    $statement=$con->prepare($query);
    $statement->execute(array(
              ":user_id"  => $user_id
              ));
    $result=$statement->fetchAll();
    foreach($result as $row)
    {
       return $row['last_activity'];
    }
}

function all_chat_history($con,$to_userid,$from_userid)
{
   $sql="SELECT *
         FROM chat_message
         WHERE (to_user_id=:to_userid AND from_user_id=:from_userid)
               OR(to_user_id=:from_userid AND from_user_id=:to_userid)
         ORDER BY timestamp DESC";
   $data=array(
       ":to_userid"  => $to_userid,
       ":from_userid"=> $from_userid
       );
   $stmt=$con->prepare($sql);
   $stmt->execute($data);
   $result=$stmt->fetchAll();
   $output="<ul class='list-unstyled'>";
   foreach($result as $row)
   {
      $username='';
      $dynamic_background='';
      $chat_message='';
      if($row['to_user_id'] ==$to_userid)
      {
         if($row['status']==2)
         {
            $username="<b class='text-success'>You</b>";
            $chat_message="<i>This message is deleted</i>";
         }else {
         $username="<button type='button' class='btn btn-danger btn-xs delete_message' id='".$row['chat_message_id']."'>&times;</button>&nbsp;<b class='text-success'>You</b>";
         $chat_message=$row['chat_message'];
         }
         $dynamic_background="background:#ffe6e6;";
      } else {
         if($row['status'] == 2)
         {
            $chat_message="<i>This message has been deleted</i>";
         } else {
            $chat_message=$row['chat_message'];
         }
         $username="<b class='text-danger'>".get_username($con,$row['from_user_id'])."</b>";
         $dynamic_background="background:#ffffe6;";
      }
      $output.="<li style='border-bottom:1px dotted #ccc;padding:6px;margin:5px;".$dynamic_background."border-radius:9px;'>
                <p>".$username." - ".$chat_message."
                   <div class='text-right text-muted'>
                       <em><small>".$row['timestamp']."</small></em>
                   </div>
                </p>
                </li>";
   }
   $output.="</ul>";
   $query="UPDATE chat_message
           SET status='0'
           WHERE to_user_id='".$from_userid."'
                 AND from_user_id='".$to_userid."'
                 AND status='1'";
   $statement=$con->prepare($query);
   $statement->execute();
   return $output;
}
function get_username($con,$from_userid)
{
   $sql="SELECT username
         FROM login
         WHERE user_id=".$from_userid."";
    $stmt=$con->prepare($sql);
    $stmt->execute();
    $result=$stmt->fetchAll();
    foreach($result as $row)
    {
       return $row['username'];
    }
}
function set_notification($conn,$to_user_id,$from_user_id)
{
   $sql="SELECT *
         FROM chat_message
         WHERE to_user_id='".$to_user_id."' AND from_user_id='".$from_user_id."'
               AND status='1'";
   $stmt=$conn->prepare($sql);
   $stmt->execute();
   $totalNoti=$stmt->rowCount();
   $output='';
   if($totalNoti > 0)
   {
      $output='<span class="label label-success">'.$totalNoti.'</span>';
   }
   return $output;
}
function get_user_typing($user_id,$con)
{
   $query="SELECT is_type
           FROM login_details
           WHERE user_id='".$user_id."'
           ORDER BY last_activity
           LIMIT 1";
   $stmt=$con->prepare($query);
   $stmt->execute();
   $result=$stmt->fetchAll();
   $output='';
   foreach($result as $row)
   {
      if($row['is_type']=='yes')
      {
      $output="<em><b><span class='text-muted'>Typing..</span></b></em>";
      }
   }
   return $output;
}
function fetch_group_chat_history($con)
{
   $query="SELECT *
           FROM chat_message
           WHERE to_user_id = '0'
           ORDER BY timestamp DESC";
   $stmt=$con->prepare($query);
   $stmt->execute();
   $result= $stmt->fetchAll();
   $output='<ul class="list-unstyled">';
   foreach($result as $row)
   {
      $username='';
      $dynamic_background='';
      $chat_message='';
      if($row['from_user_id'] == $_SESSION['user_id'])
      {
         if($row['status'] == '2')
         {
            $username="<b class='text-success'>You</b>";
            $chat_message='<em>This message hs been removed</em>';
         }
         else
         {
            $chat_message=$row['chat_message'];
            $username='<button type="button" class="btn btn-danger btn-xs delete_message" id="'.$row['chat_message_id'].'">&times;</button>&nbsp;<b class="text-success">You</b>';
         }
         $dynamic_background="background:#ffe6e6;";
      }
      else
      {
         if($row['status'] == '2')
         {
            $chat_message='<em>this message hs been removed</em>';
         }
         else
         {
            $chat_message=$row['chat_message'];
         }
         $username='<b class="text-danger">'.get_username($con,$row['from_user_id']).'</b>';
         $dynamic_background="background:#ffffe6;";
      }
      $output.='<li style="border-bottom:1px solid #ccc;padding:6px;margin:5px;'.$dynamic_background.'border-radius:9px;">
                <p>'.$username.' - '.$chat_message.'
                  <div class="text-right">
                     <em><small><span class="text-muted">'.$row['timestamp'].'</span></small></em>
                  </div>
                </p>
                </li>';
   }
   $output.='</ul>';
   return $output;
}
?>