<?php
session_start();
if(!isset($_SESSION['user_id']))
{
   header("location:login.php");
}
require "database_connection.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <title>Chat Application</title>
   <meta charset="UTF-8" />
   <meta name="description" content="Chat application" />
   <meta name="viewport" content="width=device-width,initial-scale=1.0" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <link rel='stylesheet' href='css/jquery-ui.css'>
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="css/emojionearea.min.css">
   <script src="js/jquery-1.12.4.js"></script>
   <script src="js/jquery-ui.js"></script>
   <script src="js/emojionearea.min.js"></script>
   <script src="js/jquery.form.min.js"></script>
   <style type="text/css">
   .chat_message_area {
      position:relative;
      width:100%;
      height:auto;
      background-color:#fff;
      //border:1px solid #ccc;
      border-radius:3px;
   }
   #group_chat_message {
      width:100%;
      height:auto;
      min-height:80px;
      overflow:auto;
      padding:6px 24px 6px 12px;
   }
   .image_upload {
      position:absolute;
      top:3px;
      right:3px;
   }
   .image_upload > form >input {
      display:none;
   }
   .image_upload img {
      width:24px;
      cursor:pointer;
   }
   </style>
</head>
<body>
<div class="container">
   <br>
   <h3 align="center">Chat Application with jQuery</h3>
   <br>
   <br>
   <div class="table-responsive">
    <div class="row">
      <div class="col-md-8 col-sm-6">
          <h4 align="center">Online User</h4>
      </div>
      <div class="col-md-2 col-sm-3">
         <input type="hidden" id="hidden_dialog_status" value="no">
         <button type="button" class='btn btn-sm btn-warning' id="open_group_chat">Group Chat</button>
      </div>
      <div class="col-md-2 col-sm-3">
        <p align="right">
        Hi - <?php echo $_SESSION['username'] ?? ''; ?>
         - <a href="logout.php">logout</a>
        </p>
     </div>
    </div>
   <div id="user_details"></div>
   <div id="dynamic_user_dialog"></div>
   </div>
</div>
<div id="group_chat_dialog" title="Users Group Chat">
   <div id="group_chat_history" class="group_chat_history" style="height:350px;border:1px solid #ccc;overflow-y:scroll;margin-bottom:10px;padding:9px;"></div>
   <div class="form-group">
      <!--<textarea id="group_chat_message" name="group_chat_message" class="form-control">
      </textarea>-->
      <div class="chat_message_area">
         <div id="group_chat_message" contenteditable class="form-control">
            <span id="span_chat_message"></span>
         </div>
         <div class="image_upload">
            <form id="uploadimage" method="POST" action="upload.php">
               <label for="uploadfile"><img src="images/upload.png"></label>
               <input type="file" name="uploadfile" id="uploadfile" accept=".jpg, .png">
            </form>
         </div>
      </div>
   </div>
   <div class="form-group text-right">
      <button type="button" id="group_send_chat" name="group_send_chat" class="btn btn-info btn-sm">send</button>
   </div>
</div>
<input type="text" id="test" class="form-control">
<script type="text/javascript">
$(document).ready(function() {
   function load_dynamic_dialog(to_userid,to_username)
   {
     var modal_content ='<div id="user_dialog_'+to_userid+'" class="user_dialog" title="You Have chat with '+to_username+'">';
        modal_content +='<div style="height:350px;border:1px solid #ccc;overflow-y:scroll;margin-bottom:10px;padding:9px;" id="chat_history_'+to_userid+'" class="chat_history" data-touserid="'+to_userid+'">';
        modal_content += fetch_user_chat_history(to_userid);
        modal_content += '</div>';
        modal_content +='<div class="form-group">'
        modal_content +='<textarea name="chat_message_'+to_userid+'" id="chat_message_'+to_userid+'" class="form-control chat_message"></textarea>';
        modal_content +='</div>';
        modal_content +='<div class="form-group text-right">';
        modal_content +='<button type="button" class="btn btn-sm btn-info send_chat" name="send_chat" id="'+to_userid+'">send</button>';
        modal_content +='</div>';
        modal_content +='</div>';
      $("#dynamic_user_dialog").html(modal_content);
   }
   $(document).on("click",".start_chat",function() {
      var to_userid=$(this).data("touserid");
      var to_username=$(this).data("tousername");
      load_dynamic_dialog(to_userid,to_username);
      $("#user_dialog_"+to_userid).dialog({
         autoOpen:false,
         width:350
      });
      $("#user_dialog_"+to_userid).dialog("open");
      $("#chat_message_"+to_userid).emojioneArea({
         pickerPosition:"top",
         toneStyle:"bullet"
      });
   });
   
   fetch_user_details();
   
   setInterval(function(){
      fetch_user_details();
      update_last_activity();
      update_user_chat_history();
      fetch_group_chat_history();
   },5000);
   
   function fetch_user_details() {
      $.ajax({
         url:"fetch_user.php",
         method:"POST",
         success:function(data) {
            $("#user_details").html(data);
         }
      });
   }
   
   function update_last_activity()
   {
      $.ajax({
         url:"update_last_activity.php",
         method:"POST",
         success:function(data) {
         }
      });
   }
   $(document).on("click",".send_chat",function() {
      var to_userid=$(this).attr("id");
      var chat_message=$("#chat_message_"+to_userid).val();
      $.ajax({
         url:"insert_chat.php",
         method:"POST",
         data:{
              to_userid:to_userid,
              chat_message:chat_message
              },
         success:function(data) {
            $("#chat_history_"+to_userid).html(data);
            var element=$("#chat_message_"+to_userid).emojioneArea();
            element[0].emojioneArea.setText('');
           // $("#chat_message_"+to_userid).val('');
         }
      });
   });
   function fetch_user_chat_history(to_userid)
   {
      $.ajax({
         url:"fetch_user_chat_history.php",
         method:"POST",
         data:{to_userid:to_userid},
         success:function(data) {
            $("#chat_history_"+to_userid).html(data);
         }
      });
   }
   function update_user_chat_history()
   {
      $(".chat_history").each(function() {
         var to_userid=$(this).data("touserid");
         fetch_user_chat_history(to_userid); 
      });
   }
   $(document).on("focus",".chat_message",function() {
      var is_type="yes";
      $.ajax({
         url:"get_typing_status.php",
         method:"POST",
         data:{is_type:is_type},
         success:function(data) {
            
         }
      });
   });
   $(document).on("blur",".chat_message",function() {
      var is_type="no";
      $.ajax({
         url:"get_typing_status.php",
         method:"POST",
         data:{is_type:is_type},
         success:function(data) {
            
         }
      });
   });
   $("#group_chat_dialog").dialog({
      autoOpen:false,
      width:350
   });
   $(document).on("click","#open_group_chat",function() {
      $("#group_chat_dialog").dialog("open");
      $("#hidden_dialog_status").val('yes');
      fetch_group_chat_history();
   });
   function fetch_group_chat_history()
   {
       var hidden_dialog_status=$("#hidden_dialog_status").val();
       if(hidden_dialog_status == 'yes')
       {
         $.ajax({
            url:"fetch_group_chat_history.php",
            method:"POST",
            data:{action:"fetch_data"},
            success:function(data) {
               $("#group_chat_history").html(data);
            }
         });
       }
   }
   $(document).on("click","#group_send_chat",function() {
      var chat_message=$("#group_chat_message").html();
      if(chat_message!="")
      {
         $.ajax({
            url:"fetch_group_chat_history.php",
            method:"POST",
            data:{action:"insert_data",chat_message:chat_message},
            success:function(data) {
               $("#group_chat_history").html(data);
               $("#group_chat_message").html('');
            }
         });
      }
   });
   $(document).on("click",".delete_message",function() {
      var chat_message_id=$(this).attr("id");
      if(confirm("Are you sure you want to delete this message"))
      {
         $.ajax({
            url:"delete_chat_message.php",
            method:"POST",
            data:{chat_message_id:chat_message_id},
            success:function(data) {
               update_user_chat_history();
            }
         });
      }
   });
   $(document).on("change","#uploadfile",function() {
      $("#uploadimage").ajaxSubmit({
         target:"#span_chat_message",
         resetForm:true
      });
   });
});
</script>
</body>
</html>