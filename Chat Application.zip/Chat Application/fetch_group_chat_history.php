<?php
session_start();

include("database_connection.php");

if($_POST['action'] =='insert_data')
{
   $data=array(
     ":chat_message" => $_POST['chat_message'],
     ":from_userid"  => $_SESSION['user_id'],
     ":to_userid"    => '0',
     ":status"       => '1'
     );
   $sql="
   INSERT 
   INTO chat_message(chat_message,from_user_id,to_user_id,status)
   VALUES(:chat_message,:from_userid,:to_userid,:status)
   ";
   $statement=$connection->prepare($sql);
   if($statement->execute($data))
   {
      echo fetch_group_chat_history($connection);
   }
}

if($_POST['action'] == 'fetch_data')
{
   echo fetch_group_chat_history($connection);
}
?>