<?php
session_start();

include("database_connection.php");

echo all_chat_history($connection,$_POST['to_userid'],$_SESSION['user_id']);

?>