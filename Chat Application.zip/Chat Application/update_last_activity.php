<?php

include "database_connection.php";

session_start();

$sql="UPDATE login_details
      SET last_activity=now()
      WHERE login_details_id=:login_details_id
     ";
$stmt=$connection->prepare($sql);
$stmt->execute(array(
      ":login_details_id" => ($_SESSION['login_details_id'] ?? 0)
    ));
?>