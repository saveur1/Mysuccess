<?php
session_start();
include("database_connection.php");
$sql="
     DELETE FROM login_details
     WHERE user_id=".$_SESSION['user_id']."
     ";
$stmt=$connection->prepare($sql);
$stmt->execute();
session_destroy();

header("location:login.php");
?>