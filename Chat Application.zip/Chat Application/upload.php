<?php
if(!empty($_FILES))
{
   if(is_uploaded_file($_FILES['uploadfile']['tmp_name']))
   {
      $_source_path=$_FILES['uploadfile']['tmp_name'];
      $target_path="images/".$_FILES['uploadfile']['name'];
      if(move_uploaded_file($_source_path,$target_path))
      {
         echo "<p><img src='".$target_path."' class='img-thumbnail' width='200' height='160'></p><br>";
      }
   }
}
?>