<?php

session_start();

include("database_connection.php");

if(isset($_SESSION['user_id']))
{
     header("location:index.php");
}
$error_username='';
$error_password='';
$error_confirm_password='';
$success_message='';
if(isset($_POST['register']))
{
   $error=0;
   $username=htmlspecialchars(trim($_POST['username']));
   $password=htmlspecialchars(trim($_POST['password']));
   $chech_query="SELECT * 
                 FROM login
                 WHERE username=:username";
   $stmt=$connection->prepare($chech_query);
   if($stmt->execute(array(":username"  => $username)))
   {
      if($stmt->rowCount() > 0)
      {
         $error_username="Username Already Exist";
         $error++;
      }
      else
      {
         if($username == '')
         {
            $error_username="Username is Required";
            $error++;
         }
      }
      if($password=='')
      {
         $error_password="Password is Required";
         $error++;
      }
      else
      {
         if(strlen($password)<4 || strlen($password) >20)
         {
            $error_password="Password Must be between 4 and 20 characters";
            $error++;
         }
      }
      if($_POST['confirm_password'] != $password)
      {
         $error_confirm_password="Password Mismatch";
         $error++;
      }
      if($error == 0)
      {
         $data=array(
         ":username" => $username,
         ":password" => password_hash($password,PASSWORD_DEFAULT)
         );
         $sql="INSERT
               INTO login(username,password)
               VALUES(:username,:password)";
         $statement=$connection->prepare($sql);
         if($statement->execute($data))
         {
            $success_message="You have Registered successfully!<br>Now you can <a href='login.php'>login</a>";
         }
      }
   }
   
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <title>Chat Application</title>
   <meta charset="UTF-8" />
   <meta name="description" content="Chat application" />
   <meta name="viewport" content="width=device-width,initial-scale=1.0" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <link rel='stylesheet' href='css/jquery-ui.css'>
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <script src="js/jquery-1.12.4.js"></script>
   <script src="js/jquery-ui.js"></script>
</head>
<body>
   <div class="container">
      <br>
      <h3 class="text-center">jQuery Chat Application</h3>
      <br>
      <div class="panel panel-default" style="max-width:450px;">
         <h5 class="panel-heading">Registration Form</h5>
         <div class="panel-body">
            <form method="POST">
               <p class="text-success text-center"><?php echo $success_message; ?></p>
               <div clas="form-group">
                  <label for="username">Username</label>
                  <input type="text" name="username" id="username" class="form-control" value="<?php echo $_POST['username'] ?? '' ?>">
                  <p class="text-danger"><?php echo $error_username; ?></p>
               </div>
               <div clas="form-group">
                  <label for="password">Password</label>
                  <input type="password" name="password" id="password" class="form-control">
                  <p class="text-danger"><?php echo $error_password; ?></p>
               </div>
               <div clas="form-group">
                  <label for="confirm_password">Re-Enter Password</label>
                  <input type="password" name="confirm_password" id="confirm_password" class="form-control">
                  <p class="text-danger"><?php echo $error_confirm_password; ?></p>
               </div>
               <div clas="form-group">
                  <input type="submit" name="register" id="register" class="btn btn-info btn-sm">
               </div>
               <div class="text-center">
                   <em>Have already an account <a href="login.php">Login</a></em>
               </div>
            </form>
         </div>
      </div>
   </div>
</body>
</html>