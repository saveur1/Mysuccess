<?php
require("database_connection.php");
session_start();
$data=array(
  ":to_userid"   => $_POST['to_userid'],
  ":from_userid" => $_SESSION['user_id'],
  ":chat_message"=> $_POST['chat_message'],
  ":status"      => 1
  );
  $sql="INSERT 
        INTO chat_message(to_user_id,from_user_id,chat_message,status)
        VALUES(:to_userid,:from_userid,:chat_message,:status)";
  $stmt=$connection->prepare($sql);
  if($stmt->execute($data))
  {
     echo all_chat_history($connection,$_POST['to_userid'],$_SESSION['user_id']);
  }
?>