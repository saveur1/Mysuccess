<?php
include("database_connection.php");
session_start();
$sql="
    UPDATE login_details
    SET is_type='".$_POST['is_type']."' 
    WHERE login_details_id='".$_SESSION['login_details_id']."'
    ";
$connection->exec($sql);
?>