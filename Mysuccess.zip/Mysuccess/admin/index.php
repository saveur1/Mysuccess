<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="description" content="student examination result" />
<meta name="viewport"content="width=device-width,initial-scale=1.0" />
<meta http-equiv="X-UA-Compatible"content="IE=edge" />
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.min.css">

<!--import google icons-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet"href="../css/bootstrap.min.css">
<link rel="stylesheet"href="configuration/admin.css">
<title>Mysuccess</title>
</head>
<body>
<?php include("configuration/header.php"); ?>
<div id="output">

  </div>
<?php include("configuration/footer.php"); ?>
<script type="text/javascript" src="../include/jquery-3.5.0.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="configuration/script.js"></script>

</body>
</html>