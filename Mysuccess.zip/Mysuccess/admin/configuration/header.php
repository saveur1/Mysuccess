<div class="jumbotron jumbotron-default"style="margin-bottom:0px">
     <div align="center">
        <img src="configuration/logo.png"class="img-responsive img-thumbnail" width="130"style="border:0;padding:0">
     </div>
  <h4 class="text-center mt-3">Welcome To My <span class="text-primary">Success</span></h4>
</div>
<header>
  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <a href="index.php"class="navbar-brand">Home</a>
   <button type="button"class="navbar-toggler"data-toggle="collapse"id="collapsible"><span class="navbar-toggler-icon"></span></button>
   <div class="collapse navbar-collapse">
     <ul class="navbar-nav">
     <li class="nav-item">
       <a class="nav-link" href="#">Dashbord</a>
     </li>
     <li class="nav-item">
       <a class="nav-link" href="createReport.php">Report Card</a>
     </li>
     <li class="nav-item">
       <a class="nav-link" href="#">Setting</a>
     </li>
     <li class="nav-item">
       <a class="nav-link"href="users.php">Users</a>
     </li>
     <li class="nav-item">
       <a class="nav-link" href="#">privacy</a>
     </li>
      </ul>
    </div>
  </nav>
</header>