jQuery(document).ready(function() {
  $('#collapsible').click(function() {
    $(".collapse").slideToggle();
  });
});