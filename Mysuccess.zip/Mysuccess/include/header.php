<?php include("admin/configuration/connection.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="description" content="student examination result" />
<meta name="viewport"content="width=device-width,initial-scale=1.0" />
<meta http-equiv="X-UA-Compatible"content="IE=edge" />
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.all.min.js"></script>
  <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.min.css'>
<!--import google icons-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet"href="css/bootstrap.min.css"media="screen,projection">
<script type="text/javascript" src="include/jquery-3.5.0.min.js"></script>
<script type="text/javascript" src="js/jquery.easybg.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<link rel="stylesheet"href="include/css/mycss.css"media="screen,projection">
<title>My Success</title>
<link rel="icon"href="admin/configuration/logo.png">
  <style>

  </style>
</head>
<body>
<div class="title"style="background:#f5f5f5">
  <h2 style="font-family: &quot;Comic Sans MS&quot;, &quot;Comic Sans&quot;, cursive;"><img src="img/dove.png"class="img-thumbnail"width="60"height="60"style="border:0;background:#f5f5f5;">My <span class="text-primary">Success</span></h2>
  </div>
<nav class="navbar navbar-expand-sm navbar-dark font"style="background:teal">
<a id="home"class="navbar-brand"href="index.php" style="font-family: &quot;Comic Sans MS&quot;, &quot;Comic Sans&quot;, cursive;">Home</a>
<button class="navbar-toggler"type="button"data-toggle="collapse"id="btn_open">
  <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse">
 <ul class="navbar-nav">
  <li class="nav-item">
    <a class="nav-link"href="#">Announcement</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"href="#">Contact Us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"href="#about">About Us</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"href="#">Chat</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"href="#">Group</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"href="#">Profile</a>
  </li>
 </ul>
 </div>
</nav>