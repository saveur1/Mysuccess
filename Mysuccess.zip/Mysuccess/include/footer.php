<footer class="page-footer pt-4 font"style="background:teal">
<div class="container">
<div class="row">
<div class="col-sm-12 col-md-5">
<h2 id="about"style="font-family: &quot;Comic Sans MS&quot;, &quot;Comic Sans&quot;, cursive;">ABOUT US</h2>
<p>If we're gonna be friends,you should know that I re-heat my coffee as many times as it takes to burn my tongue,I only watch horror movies through my fingers and seriously dislike elephants,although I wish them all the best.</p>
</div>
<div class="col-sm-12 col-md-5 offset-md-2">
<h2 style="font-family: &quot;Comic Sans MS&quot;, &quot;Comic Sans&quot;, cursive;">FOLLOW US</h2>
<ul class="site">
<li><a href="#">Facebook</a></li>
<li><a href="#">Instagram</a></li>
<li><a href="#">LinkedIn</a></li>
<li><a href="#">YouTube</a></li>
<li><a href="#">Twitter</a></li>
</ul>
</div>
</div>
</div>
<div class="footer-copyright text-center py-3"style="font-family: &quot;Comic Sans MS&quot;, &quot;Comic Sans&quot;, cursive;background:#016c6c;">
&copy;<?php echo date("Y"); ?> My success alright reserved
</div>
</footer>
<script type="text/javascript">
$(document).ready(function(){
 $("#btn_open").click(function() {
   $(".collapse").slideToggle();
 });
});
</script>