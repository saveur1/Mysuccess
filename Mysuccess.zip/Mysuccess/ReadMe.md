*this Project is called My success, Because It's My first project and I wanted It to be a real project, I wanted to succeed.
*It's built by Many languages and Frame work which a are:jQuery,Bootstrap,HTML, and PHP
*The PHP involved Involve using PDO as way to connect to Database.
*The project is Made by four USER which are STUDENT,TEACHER,REGISTER And ADMINISTRATOR
*Every User Has Role To play for example:
     Student,View School Report,Chat and Read         Announcement.