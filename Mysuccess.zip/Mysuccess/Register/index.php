<?php include("include/header.html"); ?>
   <div id="content">
     <div class="sub_container">
       <h2>WELCOME TO HOME PAGE</h2>
       <p>
       this system is for tracking the students data
       as well as teacher data.
       and also for making quick report.
       </p>
    </div>
   </div>
   <script type="text/javascript" src="js/student.js"></script>
  </body>
</html>